CREATE INDEX nameIndex ON Person (name(10));
CREATE INDEX titleIndex ON Production (title(10));
CREATE INDEX genreNameIndex ON GenreType (genreName);
CREATE INDEX roleNameIndex ON Role (roleName);